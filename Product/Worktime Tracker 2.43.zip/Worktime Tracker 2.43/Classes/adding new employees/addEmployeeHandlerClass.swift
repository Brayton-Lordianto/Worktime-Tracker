//
//  typeHandlerClass.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 30/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import Foundation
import SwiftUI
import CoreData

//ensures that an attempt to add an employee is completely valid.
class addEmployeeHandler {
    var name: String
    var username: String
    var password: String
    var employees: FetchedResults<Employee>
    var type: String
    var clientAcc: Client
    
    init(name: String, username: String, password: String, type: String, employees: FetchedResults<Employee>, clientAcc: Client) {
        self.name = name
        self.username = username
        self.password = password
        self.type = type
        self.employees = employees
        self.clientAcc = clientAcc
    }
    
    
    
     enum addEmployeeErrors: String {
        case none = ""
        case noName = "Please enter a name."
        case noUsername = "Please enter a username."
        case noPassword = "Please enter a password."
        case existingUsername = "The entered username already exists. Please choose a unique username."
    }
    
    func checkAddingError() -> addEmployeeErrors {
        if name == "" {
            return .noName
        } else if username == "" {
            return .noUsername
        } else if password == "" {
            return .noPassword
        }
        for employee in employees {
            if username == employee.wrappedUserName {
                return .existingUsername
            }
        }
        if username == clientAcc.wrappedUsername {
            return .existingUsername
        }
        return .none
    }
    
    func createNewEmployee(context: NSManagedObjectContext) {
        let newEmployee = Employee(context: context)
        newEmployee.name = name
        newEmployee.username = username
        newEmployee.password = password
        newEmployee.type = type
    }
    
    func handleAddingEmployee(presentation: Binding<PresentationMode>, moc: NSManagedObjectContext) -> String {
        if checkAddingError() == .none {
            createNewEmployee(context: moc)
            presentation.wrappedValue.dismiss() //for the UI
            trySave(moc: moc)
        }
        return checkAddingError().rawValue
    }
}
