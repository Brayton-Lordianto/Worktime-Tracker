//
//  addingNewLogsClass.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 31/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import Foundation
import CoreData

//handles adding new logs and when logs are manually changed by client.
class logHandler {
    var date: Date
    var employee: Employee
    var dateComponents: DateComponents {
        Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: date)
    }
    var moc: NSManagedObjectContext
    //when a check-in/out is made.
    init(employee: Employee, in moc: NSManagedObjectContext) {
        date = Date() //the current date and time of check-in/out as the date to be recorded.
        self.employee = employee //the employee that checked in or out.
        self.moc = moc
    }
    //Overloaded initializer that handles adding or deleting logs with a custom date by the client.
    init(employee: Employee, customDate: Date, in moc: NSManagedObjectContext) {
        date = customDate
        self.employee = employee
        self.moc = moc
    }
    
    func addNewLog() {
        //create a new log with the current date (timestamp), the corresponding employee, and day.
        let log = Log(context: moc)
        log.date = date 
        log.employee = employee
        //establishes the relationship of the new log with a day entity.
        log.day = connectedDay()
        //update the daily and monthly calculations related with the log's corresponding day. Then, save.
        refreshOvertimesAndWorktimes(for: log.day)
        trySave(moc: moc)
    }
    
    func deleteLog(log: Log) {
        let day = log.day!
        let month = day.month!
        moc.delete(log)
        trySave(moc: moc)
        //if the log is the only log, the day entity for the log is also deleted.
        //if the day is the only day, the month entity for the log is also deleted.
        //only day and months that have logs will be stored.
        if day.isEmpty() {
            moc.delete(day)
            trySave(moc: moc)
            if month.isEmpty() {
                moc.delete(month)
                trySave(moc: moc)
            } else {
                refreshWholeMonth(for: month)}
                trySave(moc: moc)
        }
        refreshWholeMonth(for: month)
        trySave(moc: moc)
    }
    
    func refreshOvertimesAndWorktimes(for day: Day?) {
        setDayWorktimeAndOvertime(for: day!)
        setMonthOvertime(for: day!.month!)
    }
    
    func refreshWholeMonth(for month: Month?) {
        for day in month!.dayArray {
            setDayWorktimeAndOvertime(for: day)
        }
        setMonthOvertime(for: month!)
    }
    
    //when the type of employee is changed, refresh every single month of the employee
    func refreshForChangedType(newType: types) {
        if newType != employee.wrappedType { //if the type is changed
            for month in employee.monthsArray {
                refreshWholeMonth(for: month)
            }
        }
    }

    //Searches for the day corresponding with the created log and returns it.
    //If a corresponding day or month doesn't exist, it is created.
    func connectedDay() -> Day {
        var parentDay: Day? = nil
        //check if a month exists with the same month date and employee.
        //if a month exists, check if the day exists.
        //if a month does not exist, the day must also not exist. Thus, create Day and Month entities.
        if let foundMonth = existingMonth() { //if month exists
            //if a day exists, set the day.
            //else, create a new day and set it.
            if let foundDay = existingDay(month: foundMonth) { //check if the day exists
                parentDay = foundDay
            } else {
                parentDay = createNewDay(dayDate: dateComponents, for: foundMonth)
            }
        } else {
            //creates and sets new Day and Month entities.
            let parentMonth = createNewMonth(monthDate: dateComponents)
            parentDay = createNewDay(dayDate: dateComponents, for: parentMonth)
        }
        //the added log will now have a corresponding day and month entity. The day is returned for the relationship to be established.
        //a day will definitely exist, either found or created.
        return parentDay!
    }
    
    //returns the corresponding month of the log;
    //meaning the same month date (month and year) and same employee as the log.
    //else, return nil.
    private func existingMonth() -> Month? {
        //loop through the months for the employee that logged in.
        for month in employee.monthsArray {
            //check if the month's month and year date is the same as the log's month and year date.
            if sameMonth(of: month.wrappedDate, and: dateComponents)  {
                //if so, return the month.
                return month
            }
        }
        return nil
    }
    //the corresponding month of the log is passed.
    //returns the corresponding day of the log; the same day date (month, year, day) and employee.
    //else, return nil.
    private func existingDay(month: Month) -> Day? {
        //search through all logged in days for the month that corresponds to the log's employee and month date.
        for day in month.dayArray {
            if sameDay(of: day.wrappedDate, and: dateComponents) {
                return day
            }
        }
        return nil
    }
    
    //Creates a new month and stores it in the DB and returns the created month.
    private func createNewMonth(monthDate: DateComponents) -> Month{
        let month = Month(context: moc)
        month.monthDate = Calendar.current.date(from: DateComponents(timeZone: monthDate.timeZone, year: monthDate.year, month: monthDate.month)) //store as a date to accomadate database type.
        month.employee = employee
        //save
        trySave(moc: moc)
        return month
    }
    
    //Creates a new day if needed and stores it in the DB.
    //relationship with the corresponding month is formed, the day is returned.
    private func createNewDay(dayDate: DateComponents, for month: Month) -> Day{
        let day = Day(context: moc)
        day.dayDate = Calendar.current.date(from: DateComponents(timeZone: dayDate.timeZone,year: dayDate.year, month: dayDate.month, day: dayDate.day))
        day.employee = employee
        day.month = month
        //save
        trySave(moc: moc)
        return day
    }
    
    //sets worktime and overtime for the day.
    private func setDayWorktimeAndOvertime(for day: Day) {
        let calculator = dayCalculator(day: day)
        calculator.calculateWorkTime()
        calculator.calculateDayOvertime()
    }
    //sets monthly fields.
    private func setMonthOvertime(for month: Month) {
        let calculator = monthCalculator(month: month)
        calculator.settingMonthParameters()
    }
    
}
