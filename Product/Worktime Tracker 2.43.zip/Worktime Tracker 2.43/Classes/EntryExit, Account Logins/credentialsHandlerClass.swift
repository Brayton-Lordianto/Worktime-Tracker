//
//  credentialsHandler.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI //for FetchedResults
import CoreData //for NSManagedObjectContext

//handles validating credentials of logins;
//for 1. Account login; 2. Check-in/out login check; 3. changing login modes.
class credentialsHandler {
    private var username: String
    private var password: String
    private var clientAcc: FetchedResults<Client> //SwiftUI framework used. FetchedResults Struct.
    private var employees: FetchedResults<Employee>
    private var moc: NSManagedObjectContext //Core Data framework used. NSManagedObjectContext Class.
    
    //the class is called to check credentials. To do this, it would need the entered credentials as well as the existing accounts.
    init(username: String, password: String, clientAcc: FetchedResults<Client>, employees: FetchedResults<Employee>, moc: NSManagedObjectContext) {
        self.username = username //the username entered in the username field.
        self.password = password //password field entered password.
        self.clientAcc = clientAcc //the Client entity in the DB.
        self.employees = employees //the Employee entity in the DB.
        self.moc = moc //environment– used for saving to the DB context. Will be passed to LOGHANDLER class.
    }
    
    //called if there are no existing client accounts. e.g. the first time the program is ever installed and opened.
    func initClient() { //hard codes the client account with necessary information.
        let client = Client(context: moc)
        client.name = "Samuel Lordianto"
        client.username = "Samuel"
        client.password = "example"
        trySave(moc: moc)
    }
    
    
    //returns the client corresponding with the entered username.
    public func existingUsernameClient() -> Client? {
        if clientAcc[0].username == username {
            return clientAcc[0]
        }
        return nil
    }
    
    //returns the employee corresponding with the entered username.
    public func existingUsernameEmployee() -> Employee? {
        for num in (0 ... employees.count - 1) {
            if employees[num].username == username {
                return employees[num]
            }
        }
        return nil
    }
    
    
    //characterizes the login after checking the credentials. Strings denote error messages.
    enum credentialPossibilities: String {
        case noUsernameEntered = "Please enter a username."
        case noPasswordEntered = "Please enter a password."
        case noExistingUsername = "No such username stored."
        case clientMismatch = "The client password does not match."
        case employeeMismatch = "The employee password does not match. Please contact the client for information."
        //the error message for the below case is only used when an employee attempts to change the login mode.
        case employeeMatch = "Matching employee credentials entered. Only clients can switch between check-in/out and account logins."
        //the error message for the below case is only used when the client attempts to check-in or out.
        case clientMatch = "A client cannot do entry/exit logs. Please check the current mode."
    }
    
    //checks the credentials and checks the validity. Returns the credential possibility type.
    func checkCredentials() -> credentialPossibilities {
        if username == "" {return credentialPossibilities.noUsernameEntered} //if empty username
        else if password == "" {return credentialPossibilities.noPasswordEntered} //if empty password
        else if let client = existingUsernameClient() { //if a client with the typed username exists,
            if client.password == password { //if password matches,
                return credentialPossibilities.clientMatch
            }
            return credentialPossibilities.clientMismatch
        }
        else if !employees.isEmpty {
            if let employee = existingUsernameEmployee() { //for employee with same username.
                if employee.password == password {
                    return credentialPossibilities.employeeMatch
                }
                return credentialPossibilities.employeeMismatch
            }
        }
        return credentialPossibilities.noExistingUsername
    }
    
    //adds the log when entry/exit login is made.
    func addNewLogAndConnections() {
        let logger = logHandler(employee: existingUsernameEmployee()!, in: moc)
        logger.addNewLog()
    }
    
    //check credentials for a client account, returning an error if any.
    func handleChangeMode() -> String {
        if checkCredentials() == .clientMatch {
            return "" //returns no error
        }
        return checkCredentials().rawValue //returns appropriate error
    }
    
    //called everytime an check-in/check-out login is attempted.
    func handleCheckInOutLogin() -> String {
        //if a valid employee login is made, a new log is added. Success message returned.
        //else, the corresponding error message is returned.
        if checkCredentials() == .employeeMatch {
            //if-let used to avoid force unwrapping existingUsernameEmployee optional (general code convention)
            if let correspondingEmployee = existingUsernameEmployee() {
                //Add a new Log. Passes the employee and the managed object context to class logHandler.
                let logger = logHandler(employee: correspondingEmployee, in: moc)
                logger.addNewLog()
                return "\(correspondingEmployee.wrappedName) succesfully Checked in/out. Your timestamp is recorded."
            }
        }
        return checkCredentials().rawValue
    }
    
    //when goClientAccount is true, the login page will be redirected to the client page.
    //when goEmployeeAccount is true, the login page will be redirected to an employee page.
    func handleAccountLogin(goClientAccount: Binding<Bool>, goEmployeeAccount: Binding<Bool>, boundEmployee: Binding<Employee?>) -> String {
        if checkCredentials() == .clientMatch {
            goClientAccount.wrappedValue.toggle()
            return ""
        } else if checkCredentials() == .employeeMatch {
            boundEmployee.wrappedValue = existingUsernameEmployee()!
            goEmployeeAccount.wrappedValue.toggle()
            return ""
        }
        return checkCredentials().rawValue
    }

    
}
