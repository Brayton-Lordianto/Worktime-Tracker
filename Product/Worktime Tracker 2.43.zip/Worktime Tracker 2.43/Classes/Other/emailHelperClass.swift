//
//  emailHelperClass.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 16/11/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import MessageUI
import SwiftUI

//MARK: Some Of The Code Used Is Based On The Article: https://thinkdiff.net/ios/swiftui-how-to-send-email/
class EmailHelper: NSObject, MFMailComposeViewControllerDelegate {
    public static let shared = EmailHelper() //this static property is needed to have the email sheet view called at the end of the stack. Allows mailComposeController:didFinishWith to be called to dismiss.
    //MARK: This emailing method is specifically modified for sending the JSON data both as a nicely printed String AND an attached JSON file.
    func sendEmail(subject:String, body:String, to:String, data: Data?){
        //the method has a subject,body,receiving email, and data. The body should be the JSON data as a printed string.
        if !MFMailComposeViewController.canSendMail() { //cases such as no email in the device's Apple mail app.
            print("ERROR SENDING MAIL")
            return //EXIT
        }
        
        let picker = MFMailComposeViewController() //the sheet
        //setting appropriate information for the email
        picker.setSubject(subject)
        picker.setMessageBody(body, isHTML: false) //not HTML to allow text to be nicely printed.
        picker.setToRecipients([to]) //this will be the stored client email.
        picker.mailComposeDelegate = self //sets the mailcomposedelegate to self
        //sending the attachment of the data as a JSON file.
        if let JSONData = data {
            //mime type for JSON is application/json
            picker.addAttachmentData(JSONData, mimeType: "application/json", fileName: subject)
        }
        EmailHelper.getRootViewController()?.present(picker, animated: true, completion: nil) //show the email sheet.
    }
    //dismiss the email sheet view after sent.
    public func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Swift.Error?) {
        if result == .failed {
            print("FAILED TO SEND EMAIL.")
        }
        EmailHelper.getRootViewController()?.dismiss(animated: true, completion: nil) //dismiss
    }
    
    static func getRootViewController() -> UIViewController? { //returns the UIViewController (the email sheet)
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.window?.rootViewController //code from website
    }
}
