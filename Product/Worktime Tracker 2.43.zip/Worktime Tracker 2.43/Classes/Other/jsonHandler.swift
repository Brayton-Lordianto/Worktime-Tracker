//
//  jsonHandler.swift
//  Worktime Tracker 2.4
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//

import Foundation
import SwiftUI

//handles the conversion to JSON data and calling the prompt to send an email.
class jsonHandler {
    var dateToSend: String
    var monthReq: FetchedResults<Month>
    var emailHelper = EmailHelper.shared //this is the shared email helper defined in the EmailHelper class
    var objArr: [toBeJsonEmployee] = []
    var clientEmail: String
    
    //receives all the months, the specific month and year component to send, and the client.
    init(months: FetchedResults<Month>, monthToSend: Int, yearToSend: Int, client: Client) {
        dateToSend = "\(DateFormatter().monthSymbols[monthToSend-1]) \(yearToSend)"
        clientEmail = client.wrappedEmail
        monthReq = months
        setObjArr(monthNum: monthToSend, yearNum: yearToSend)
    }
    //sets the array of objects that will be converted to JSON
    func setObjArr(monthNum: Int, yearNum: Int) {
        //loop through all months and find the months with the selected month
        for month in monthReq {
            if month.wrappedDate.month == monthNum && month.wrappedDate.year == yearNum {
                //from all months to send as a JSON, create the data with information needed.
                let jsonObj = toBeJsonEmployee(month: month)
                objArr.append(jsonObj)
            }
        }
    }
    
    //get the JSON data and the String data,and concurrently email it. Thinking Concurrently.
    //parameter showAlert is a 2 way binding that connects back with the GUI-> when true, an alert will prompt
    func emailJsonData(showAlert: Binding<Bool>) {
        //if there is no data to send, show an alert.
        if objArr.isEmpty {
            showAlert.wrappedValue.toggle() //prompt the alert
            return }
        //get the data
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted //printed pretty as JSON text
        do { //do-catch: thinking ahead
            let data = try encoder.encode(objArr) //encode the object
            if let stringData = String(data: data, encoding: .utf8){ //the data as a string
                emailHelper.sendEmail(subject: "JSON info+file for \(dateToSend)", body: stringData, to: clientEmail, data: data)
            }
        } catch {
            print(error.localizedDescription) //print error
        }
    }
}

struct toBeJsonEmployee: Encodable {
    //information that need to be in the JSON.
    var name: String
    var username: String
    var extraWageType: String
    var monthlyOvertime: Int16
    var diligenceAbsences: Int16

    init(month: Month) {
        name = month.employee!.wrappedName
        username = month.employee!.wrappedUserName
        extraWageType = month.employee!.wrappedType.rawValue
        monthlyOvertime = month.monthOvertime
        diligenceAbsences = month.diligenceAbsence
    }
}
