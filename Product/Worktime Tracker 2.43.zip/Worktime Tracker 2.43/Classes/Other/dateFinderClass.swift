//
//  DateFinder.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 15/11/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import Foundation

//called when using the datepicker.
class selectedDateHandler {
    private var date: DateComponents
    private var employee: Employee
    private var month: Month?
    private var day: Day?
    init(date: Date, employee: Employee) {
        self.date = Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: date)
        self.employee = employee
        self.month = returnMonth()
        self.day = returnDay()
    }
    
    //identifies a month that corresponds with the picked date.
     func returnMonth() -> Month? {
        for month in employee.monthsArray {
            if sameMonth(of: month.wrappedDate, and: date) {
                return month
            }
        }
        return nil
    }
    //identifies a day that corresponds with the picked date.
    func returnDay() -> Day? {
        if let month = self.month {
            for day in month.dayArray {
                if sameDay(of: day.wrappedDate, and: date) {
                    return day
                }
            }
        }
        return nil
    }
    
    func present() -> Bool {
        (returnDay() != nil)
    }
    
    func worktimeHoursString() -> String {
        let worktime = returnDay()?.worktime ?? 0
        if worktime == -3 {
            return "There is an odd number of logs on this day."
        } else if !present() {
            return "0"
        }
        return worktime.description
    }
    
    
    func overtimeHoursString() -> String {
        if employee.wrappedType == .normalPay {
            let overtime = returnDay()?.dayOvertime ?? 0
            if overtime == -3 {
                return "No overtime because of odd number of logs."
            } else if !present() {
                return "-2 (Default for Absences)"
            }
            return overtime.description
        } else {
            return "N/A (Not a normal pay employee)"
        }
    }
    
    func monthlyString() -> String {
            if employee.wrappedType == .normalPay {
                return "Monthly Overtime"
            } else if employee.wrappedType == .diligencePay {
                return "Diligence Absences (0, 1, 2, 3)"
            } else {
                return "Extra Pay"
            }
        }
    
    func monthlyWagesString() -> String {
        if employee.wrappedType == .normalPay {
            let overtime = returnMonth()?.monthOvertime ?? 0
            if overtime == -3 {return "No overtime because of odd number of logs."}
            return "\(overtime.description)"
        } else if employee.wrappedType == .diligencePay {
            return "\(returnMonth()?.diligenceAbsence.description ?? "0")"
        } else if employee.wrappedType == .fixedExtraPay {
            return "Fixed Extra Pay"
        } else if employee.wrappedType == .canceledBonus {
            return "Bonus Is Canceled"
        } else {
            return "None"
        }
    }
}
