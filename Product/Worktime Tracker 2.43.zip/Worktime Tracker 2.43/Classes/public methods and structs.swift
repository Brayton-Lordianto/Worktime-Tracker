//
//  public methods and structs.swift
//  Worktime Tracker 2.4
//
//  Created by Brayton Lordianto on 02/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//

import Foundation
import CoreData
import SwiftUI

struct editableField: View {
    //only for employee account stuff
    var text: String
    var textFieldContent: Binding<String>
    var disabled: Bool
    var body: some View {
        HStack {
            Text("\(text):")
            TextField(textFieldContent.wrappedValue, text: textFieldContent)
                .autocapitalization(.none)
                .disabled(self.disabled)
        }
    }
}

//saves DB if there are changes. Return value may or may not be used.
//returns true if there are changes and changes are saved. else, return false.
func trySave(moc: NSManagedObjectContext) {
    if (moc.hasChanges) {
        //changing data from the program takes precedence over changing data directly from the core data sqlite DB. Ensures no conflict of saving in both places. Thinking Ahead.
        moc.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        do {
            try moc.save()
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
    }
}

//enum of the different types of employees. public because it is used everywhere.
public enum types: String, CaseIterable {
    case normalPay = "Normal Pay Employee"
    case noExtraPay = "No Extra Pay Employee"
    case diligencePay = "Diligence Pay Employee"
    case fixedExtraPay = "Fixed Extra Pay Employee"
    case canceledBonus = "Canceled Bonus Employee"
}

//functions made public to ease handling dates. Timezone used is UTC.
public func sameMonth(of month1: DateComponents, and month2: DateComponents) -> Bool {
    return (month1.year == month2.year) && (month1.month == month2.month)
}
public func sameDay(of day1: DateComponents, and day2: DateComponents) -> Bool {
    return (day1.day == day2.day)
}
public func returnDateWithComponents(year: Int, month: Int, day: Int, hour: Int, minute: Int) -> Date {
    Calendar.current.date(from: DateComponents(calendar: .current, timeZone: TimeZone(abbreviation: "UTC"), year: year, month: month, day: day, hour: hour, minute: minute))!
}

//MARK: This is used to populate testing logs.
public func populateLogsForTesting(dateSet: [Date], for employee: Employee, in moc: NSManagedObjectContext) {
    for date in dateSet {
        let logClass = logHandler(employee: employee, customDate: date, in: moc)
        logClass.addNewLog()
    }
}

public var information: String =
"Enter your credentials for either a check-in/check-out and user account login. \n\n Check-in or Check-outs are on-site logins for logging in or out. As employees, your time of login will be recorded. If you have duplicated logins or forgot to login, contact the client. \n\n Users can also login to their user account through the default account login mode. If you are not a client, you cannot change modes for security reasons. For a client, you can change the mode by pressing the 'Change the Login Mode' button. \n\n Thank you for using Worktime Tracker. Contact the client for questions if needed."

