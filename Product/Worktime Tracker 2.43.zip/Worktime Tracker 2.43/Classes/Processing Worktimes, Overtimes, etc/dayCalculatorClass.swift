//
//  DayCalculator.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import Foundation

//calculates day: worktime and (for normal pay employees,) overtime.
//called whenever a new check-in/check-out is made, or when a log is changed by the client.
class dayCalculator {
    var day: Day
    //the class calculates for a passed Day entity.
    init(day: Day) {
        self.day = day
    }
    
    //calculates and sets the worktime for the day.
    func calculateWorkTime() {
        if day.logArray.count % 2 == 0 { //If there is an check-out for every check-in
            var worktime = 0.0
            //logArray is sorted by date. The loop calculates the worktime of each login/logout pair.
            for logNum in 1...(day.logArray.count / 2) {
                //for every pair, get the check-in.
                let entryLog = day.logArray[2 * logNum - 2] //0, 2, 4... even array index
                //get the check-out.
                let exitLog = day.logArray[2 * logNum - 1] //1, 3, 5... odd array index
                //calculate the worked time and add to total work time.
                let hours = (exitLog.wrappedDate.hour ?? 0) - (entryLog.wrappedDate.hour ?? 0)
                let minutes = (exitLog.wrappedDate.minute ?? 0) - (entryLog.wrappedDate.minute ?? 0)
                worktime += Double(hours + (minutes / 60)) //estimate worktime in hours.
            }
            day.worktime = Int16(round(worktime))
            return
        }
        //else, -3 will be set to denote incomplete logs for the day.
        day.worktime = -3
    }
    
    //calculates and sets daily overtime for normalPay workers.
    func calculateDayOvertime() {
        if day.employee?.wrappedType == .normalPay {
            var overtime: Int16 = 0
            if day.worktime == -3 { //-3 denotes incomplete logs for the day.
                day.dayOvertime = -3
                return
            } else if day.wrappedDate.weekday != 7 { //if day is Monday - Friday
                overtime = day.worktime - 8 //weekday quota is 8
            } else { //day is a Saturday.
                overtime = day.worktime - 5 //Saturday weekend quota is 5
            }
            if overtime < -2 {//cap daily negative overtime
                day.dayOvertime = -2
            } else {
                day.dayOvertime = overtime
            }
        }
    }
}
