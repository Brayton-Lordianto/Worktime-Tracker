//
//  monthCalculatorClass.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 01/11/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import Foundation

//called when monthly processing needs to be updated. ex. when a check-in/out is made, or when logs are manually changed.
//responsible for processing crucial month information for all types of employees.
//tracks absent and days with incomplete checkin/out logins.
class monthCalculator {
    private var month: Month
    private var fullDays: Int = 0 //how many days in the month. Will be set.
    private var dayToOvertime: [Int : Int16] = [:] //overtime on day X.
    private var weekToHours: [Int: Int16] = [:] //how many hours in the week.
    private var monthlyOvertime: Int16 = 0 //final monthly overtime
    //this is made public because it will be accessed by the UI in the Status to Day page.
    public var dayToStatus: [Int: String] = [:] //ABSENT/PRESENT/ODD_LOGS at day X.
    private var absentDays = 0 //number of absent days
    
    init(month: Month) { //processes for passed month.
        self.month = month
        self.fullDays = self.setNumOfFullDays() //find the number of full days in the month and set.
        self.setDicts() //sets all the needed dictionaries in one method.
    }
    
        
    //not necessary...
    public func setOtherTypes() {

    }
    
    private func setNumOfFullDays() -> Int {
        numOfDays(month: month)
    }
    
    //receives the date components of the current month in processing.
    //returns whether the month is a leap month.
    private func isLeap(components: DateComponents) -> Bool {
        //if a 29th of February lies on February, then it is a leap month.
        let day29 = Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: Calendar.current.date(from:
            DateComponents(calendar: .current, timeZone: TimeZone(abbreviation: "UTC"), day: 29)) ?? Date()) //find if the 29th day of the month belongs to the next month. If true, it is a leap month.
        return (day29.month == 2)
    }
    
    //receives the month in processing
    //returns the number of days in the month (NOT the number of days the employee logs in)
    private func numOfDays(month: Month) -> Int {
        let months31 = [1, 3, 5 ,7, 8, 10, 12] //month numbers with 31 days
        var num = 30 //other months have 30 days, set this as default.
        if month.wrappedDate.month == 2 { //February. February has a leap day.
            (isLeap(components: month.wrappedDate)) ? (num = 29) : (num = 28)
        } else {
            for month31 in months31 { //if it is a month with 31 days, change num to 31
                if month.wrappedDate.month == month31 {
                    num = 31
                }
            }
        }
        return num
    }
    
    //Use limited date components to make a date, then translate it into a full datecomponent set.
    private func dateComponentOfDay(day: Int) -> DateComponents {
        let tempDate = DateComponents(calendar: .current, timeZone: TimeZone(abbreviation: "UTC"),year: month.wrappedDate.year, month: month.wrappedDate.month!, day: day).date
        return Calendar.current.dateComponents(in: month.wrappedDate.timeZone!, from: tempDate!)
    }
    
    //by looping through each day of the month, the function sets the important dictionaries by considering absences, daily worktimes/overtimes and weekly overtimes, all done concurrently.
    private func setDicts() {
        var idx = 0 //represents the index of month
        var week = 1 //for weekly overtime
        var weeklyOvertime: Int16 = 0 //for weekly overtime
        for day in 1...fullDays { //loop through all days of the month
                if dateComponentOfDay(day: day).weekday == 1 { //it is a sunday.
                    dayToOvertime.updateValue(0, forKey: day)
                    dayToStatus.updateValue("SUNDAY", forKey: day)
                } else {
                    var absent = true
                    if idx < month.dayArray.count {
                        let idxDay = month.dayArray[idx]
                        //if the earliest logged date of the month is the current looped day;
                        //the employee is PRESENT at the current looped day. Set overtime.
                        if day == idxDay.wrappedDate.day {
                            dayToStatus.updateValue("PRESENT", forKey: day)
                            if idxDay.dayOvertime == -3 {
                                monthlyOvertime = -3
                                dayToStatus.updateValue("ODD NUMBER OF LOGS", forKey: day)
                            }
                            dayToOvertime.updateValue(idxDay.dayOvertime, forKey: day)
                            idx += 1 //go to the next earliest logged date of the month.
                            absent = false
                        }
                    }
                    if absent {
                        dayToOvertime.updateValue(-2, forKey: day)
                        dayToStatus.updateValue("ABSENT", forKey: day)
                        absentDays += 1 //increment absent days
                    }
                }
            //this algorithm calculates, caps, and stores weekly overtime.
            if month.employee?.wrappedType == .normalPay {
                //if the next day is not part of the week of the current looped day
                if dateComponentOfDay(day: day+1).weekOfMonth! == week {
                    weeklyOvertime += dayToOvertime[day] ?? 0 //add overtime to total weekly overtime
                } else {
                    weeklyOvertime += dayToOvertime[day] ?? 0
                    //cap and set weekly overtime for the current week.
                    if weeklyOvertime < -4 {weekToHours.updateValue(-4, forKey: week)}
                    else {weekToHours.updateValue(weeklyOvertime, forKey: week)}
                    //move to calculate monthly overtime of the next week, if not end of loop.
                    week += 1
                    weeklyOvertime = 0
                }
            }
        }
    }

    //setting and capping absences for diligence pay workers.
    public func setDiligenceAbsence() {
        if month.employee?.wrappedType == .diligencePay {
            //A ternary operation that caps the diligence absence to 3 at most.
            month.diligenceAbsence = (self.absentDays > 3) ? 3 : Int16(absentDays)
        }
    }
    
    //calculates monthly overtime for normal pay workers.
    func calculateMonthlyOvertime() {
            if monthlyOvertime != -3 {
                var tempOvertime: Int16 = 0
                for (_, hours) in weekToHours { //adds up all the overtime hours of the weeks of the month.
                    tempOvertime += hours
                }
                if tempOvertime < 0 { //caps the overtime to 0 at least.
                    monthlyOvertime = 0
                } else {
                    monthlyOvertime = tempOvertime
                }
            }
            month.monthOvertime = monthlyOvertime //set to -3 if there are day/s with odd number of logs.
    }
    
    
    //set the appropriate month fields.
    func settingMonthParameters() {
        if month.employee?.wrappedType == .normalPay {
            calculateMonthlyOvertime()
        } else if month.employee?.wrappedType == .diligencePay {
            setDiligenceAbsence()
        } else {
            setOtherTypes()
        }
    }
}
