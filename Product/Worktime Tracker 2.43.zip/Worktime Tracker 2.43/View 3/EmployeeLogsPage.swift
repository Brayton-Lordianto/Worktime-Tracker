//
//  EmployeeLogsPage.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI
//extension Calendar {
//    func dateBySettingTimeFrom(timeZone: TimeZone, of date: Date) -> Date? {
//        var components = dateComponents(in: timeZone, from: date)
//        components.timeZone = self.timeZone
//        return self.date(from: components)
//    }
//}

struct EmployeeLogsPage: View {
    private var dateFormatted: String {
        "\(day.wrappedDate.day ?? 0) \(DateFormatter().monthSymbols[((day.wrappedDate.month ?? 1) - 1)]) \(day.wrappedDate.month ?? 2021)"
    } //date formatted
    @Environment(\.managedObjectContext) private var moc //context
    @Environment(\.editMode) private var isEditing //edit mode
    private var employee: Employee //logs for this employee
    private var day: Day //logs for this day
    private var isClient: Bool
    @State private var logs: [Date]
    @State private var saved = false
    @State private var dateToAdd = Date()
    @State private var added = false
    //this view is called from the employee account page.
    //the employee and day and whether the user accessing the page is a client is passed to this view.
    init(employee: Employee, day: Day, isClient: Bool) {
        self.employee = employee
        self.day = day
        self.isClient = isClient //if the client calls this view, this will be true.
        //converts the day's logs into an array of dates local to EmployeeLogsPage view.
        var arr: [Date] = []
        for log in day.logArray { //add a date into the empty array for each log of the day.
            arr.append(log.date ?? Date())
        }
        _logs = State(initialValue: arr) //initialize the empty array.
    }
    
    
    var body: some View { //this view can be viewed by an employee for his own logs or the client viewing an employee's logs.
        List {
            if isClient { //option to save only available for clients. isClient is true when a client is accessing the logs page.
                Button("Save Changes"){self.saveLogChanges()}
                if saved {Text("Saved.")}
            } //save button GUI
            //if there are logs for the day, list the logs.
            if logs.count >= 1 {
                //For each index of the logs, show a datepicker for the log of the corresponding index
                ForEach(0...logs.count-1, id: \.self){ idx in
                    DatePicker(selection: Binding(
                        //custom get-set binding of logs on the list that returns the log of the index.
                        get: {return self.logs[idx]},
                        set: {return self.logs[idx] = $0}),
                        //display the hour and minute of the log only
                        displayedComponents: .hourAndMinute) {Text("")}
                    .labelsHidden()
                    .disabled(!self.isClient) //ensures that only the client can change logs
                }
                .onDelete(perform: deleteLog)
                //ensures delete only when editing to make delete more secure and complex. Thinking Ahead.
                .deleteDisabled(!(isEditing?.wrappedValue.isEditing ?? false))
            }
            if isClient { //an option to add logs, which is only available for the client.
                Section{
                    //display a datepicker and a button to add the date and time into the day's logs
                    DatePicker(selection: $dateToAdd, displayedComponents: .hourAndMinute){Text("")}
                    .labelsHidden()
                    Button("Add"){self.manualAddLog()}
                    if added {Text("Added Succesfully.")} //added message displayed
                }
            }
        }
        .navigationBarItems(trailing: EditButton().disabled(!isClient)) //only clients can edit
        .navigationViewStyle(StackNavigationViewStyle()) //allows stack view for ipad view
        .navigationBarTitle(dateFormatted)
    }
    
    func saveLogChanges() {
        //rewrite all logs and save the logs in the DB if there are changes
        for index in 0...logs.count-1 {
            day.logArray[index].date = logs[index]
        }
        if moc.hasChanges {
            //if there are changes, save the new logs into the database and update the corresponding daily and monthly calculations
            trySave(moc: moc)
            logHandler(employee: employee, customDate: day.dayDate!, in: moc).refreshOvertimesAndWorktimes(for: day)
            trySave(moc: moc)
        }
        saved = true //display saved message
        added = false //dismiss added message if a log was added beforehand.
    }
    
    //deletes the log in the DB and the list.
    func deleteLog(at offsets: IndexSet) {
        for offset in offsets { //in case there are multiple offsets, use a for loop
            //remove from the log from the DB, and refresh the calculations
            logHandler(employee: employee, in: moc).deleteLog(log: day.logArray[offset])
            logs.remove(at: offset) //remove from the list to update as well. Thinking Concurrently.
        }
        added = false
        saved = false
    }
    
    func manualAddLog() {
        //get the components of the chosen date in the datepicker.
        let componentsToAdd = Calendar.current.dateComponents([.hour, .minute], from: dateToAdd)
        //convert it into a Date data type
        let actualDateToAdd = returnDateWithComponents(year: day.wrappedDate.year!, month: day.wrappedDate.month!, day: day.wrappedDate.day!, hour: componentsToAdd.hour!, minute: componentsToAdd.minute!)
        //add the log through the handler into the DB along with updating calculations.
        let logger = logHandler(employee: employee, customDate: actualDateToAdd, in: moc)
        logger.addNewLog()
        logs.append(actualDateToAdd) //upate on the list. Thinking Concurrently.
        logs = logs.sorted() //sort the dates in ascending order of dates when added.
        added = true //display added message
        saved = false //dismiss saved message if changes made beforehand.
    }
}

//struct EmployeeLogsPage_Previews: PreviewProvider {
//    static var previews: some View {
//        EmployeeLogsPage()
//    }
//}
