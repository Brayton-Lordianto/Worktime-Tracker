//
//  AddClientView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct sectionForm: View {
    var displayText: String
    var fieldText: String
    var bind: Binding<String>
    var body: some View {
        Section(header: Text(displayText)) {
            HStack {
                TextField(fieldText, text: bind)
            }
        }
    }
}

struct AddEmployeeView: View {
    var client: Client
    @Environment(\.managedObjectContext) var moc
    @Environment(\.presentationMode) var presentation
    var handler: addEmployeeHandler {
        addEmployeeHandler(name: name, username: username, password: password, type: type.rawValue, employees: employees, clientAcc: client)
    }
    @FetchRequest<Employee>(entity: Employee.entity(), sortDescriptors: []) var employees: FetchedResults<Employee>
    
    @State var name = ""
    @State var password = ""
    @State var username = ""
    @State var type: types = .normalPay
    
    @State var errorMessage = ""
    
    var body: some View {
        NavigationView {
            Form {
                sectionForm(displayText: "Name: ", fieldText: "Enter Name Of New Employee Here", bind: $name)
                sectionForm(displayText: "Username: ", fieldText: "Enter Username Here", bind: $username)
                sectionForm(displayText: "Password: ", fieldText: "Enter Password Here", bind: $password)

                Section(header: Text("Type")) {
                    Picker(selection: $type, label: Text("")){
                        ForEach(types.allCases, id: \.self) { typeCase in
                            Text(typeCase.rawValue).tag(typeCase)
                        }
                    }.pickerStyle(WheelPickerStyle())
                }
                
                if errorMessage != "" {
                    Text("\(errorMessage)")
                        .foregroundColor(Color.red)
                }
                
            }
            .navigationBarTitle("Add New Employee")
            .navigationBarItems(trailing: Button("Add Employee"){
                self.errorMessage = self.handler.handleAddingEmployee(presentation: self.presentation, moc: self.moc)
            })
            .navigationViewStyle(StackNavigationViewStyle())
            .padding(0)
        }
    }
}

//
//struct AddClientView_Previews: PreviewProvider {
//    static var previews: some View {
//        AddClientView()
//    }
//}
