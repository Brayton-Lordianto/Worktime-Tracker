//
//  SelectedEmployeeAccountView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct SelectedEmployeeAccountView: View {
    var employee: Employee
    @State var view: EmployeeAccountView
    var name: String {
        view.name
    }
    
    init(employee: Employee) {
        _view = State(wrappedValue: EmployeeAccountView(employee: employee, isClient: true))
        self.employee = employee
    }
    
    var body: some View {
        view
    }
}

//struct SelectedEmployeeAccountView_Previews: PreviewProvider {
//    static var previews: some View {
//        SelectedEmployeeAccountView()
//    }
//}
