//
//  AbsentAndOddDaysView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 09/12/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct AbsentAndOddDaysView: View {
    var month: Month
    var dayToStatus: [Int: String] {
        return monthCalculator(month: month).dayToStatus
    }
    var calc: monthCalculator {
        monthCalculator(month: month)
    }
    var title: String {
        "\(DateFormatter().monthSymbols[(month.wrappedDate.month ?? 0)-1]) \(month.wrappedDate.year ?? 2021)"
    }
    var body: some View {
        List {
            Text("DAY NUMBER \t\t STATUS")
            ForEach(dayToStatus.sorted(by: <), id: \.key) {key, value in
                Text("\(key) \t\t\t\t\t \(value)")
            }
        }
        .onAppear() {
            
        }
    .navigationViewStyle(StackNavigationViewStyle())
    .navigationBarTitle(title)
    }
    
}
//
//struct AbsentAndOddDaysView_Previews: PreviewProvider {
//    static var previews: some View {
//        AbsentAndOddDaysView()
//    }
//}
