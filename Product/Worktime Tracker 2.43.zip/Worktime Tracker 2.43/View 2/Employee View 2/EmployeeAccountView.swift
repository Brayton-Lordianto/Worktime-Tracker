//
//  EmployeeAccountView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct clientSaveButton: View {
    var isClient: Bool
    var method: () -> Void
    var body: some View {
        ZStack{
            EmptyView()
            if isClient {
                Button(action: self.method) {
                    Text("Save Changes")
                }
            }
        }
    }
}

struct EmployeeAccountView: View {
    var employee: Employee
    @Environment(\.managedObjectContext) var moc
    @State var date = Date()
    @State var name: String
    @State var username: String
    @State var type: types
    @State var isClient: Bool
    @State var password: String
    @State private var saveMessage = ""
    var finder: selectedDateHandler {selectedDateHandler(date: date, employee: employee)}
    @State private var refreshingID = UUID()
    
    init(employee: Employee, isClient: Bool) {
        self.employee = employee
        _name = State(initialValue: employee.wrappedName)
        _username = State(initialValue: employee.wrappedUserName)
        _password = State(initialValue: employee.wrappedPassword)
        _type = State(initialValue: employee.wrappedType)
        _isClient = State(initialValue: isClient)
    }
    
    var body: some View {
        Form {
            if (!isClient) {
                Section {
                    EmptyView()
                }
            }
            Section {
                EmptyView()
                editableField(text: "Name", textFieldContent: $name, disabled: !isClient)
                editableField(text: "Username", textFieldContent: $username, disabled: true)
                HStack {
                    Text("Password: ")
                    SecureField("Password", text: $password)
                }
                Picker(selection: $type, label: Text("Type Of Overtime Calculation")){
                    ForEach(types.allCases, id: \.self) { typeCase in
                        Text(typeCase.rawValue).tag(typeCase)
                    }
                }
                .disabled(!isClient)
            }
            if saveMessage != "" {
                Section {
                    Text(saveMessage)
                }
            }
            
            DatePicker(selection: self.$date, displayedComponents: .date) {
                HStack {
                    Text("Pick a Date \t\t")
                    Text((DateFormatter().weekdaySymbols[Calendar.current.component(.weekday, from: date)-1]))
                        .font(.subheadline)
                        .foregroundColor(.blue)
                        .padding()
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke())
                }
            }
            //set id to allow refreshing.
            Section(header: Text("Status")) {
                Text(finder.present() ? "Present" : "Absent").id(refreshingID)
            }
            Section(header: Text("Daily Worktime")) {
                Text(finder.worktimeHoursString()).id(refreshingID)
            }
            if employee.wrappedType == .normalPay{
                Section(header: Text("Daily Overtime")) {
                    Text(finder.overtimeHoursString()).id(refreshingID)
                }
            }
            Section(header: Text(finder.monthlyString())) {
                Text(finder.monthlyWagesString()).id(refreshingID)
            }
            Section {
                if finder.present() {
                    NavigationLink(destination: EmployeeLogsPage(employee: employee, day: finder.returnDay()!, isClient: isClient)) {
                        Text("To Logs Page")
                    }
                } else {
                    Text("No Logs This Day.")
                }
            } //logs page
                
            Section{
                if finder.returnMonth() != nil {
                    NavigationLink(destination: AbsentAndOddDaysView(month: finder.returnMonth()!)) {
                        Text("View All Absent And Odd Days For The Month")
                    }
                } else {
                    Text("There are no records of your attendance in this month.")
                }
            } //day status
            .navigationBarItems(trailing: Button("Save Changes"){self.saveEmployeeInfo()})
            .navigationBarTitle("\(employee.wrappedName)", displayMode: .inline)
        }
    .navigationViewStyle(StackNavigationViewStyle()) //allow stack view for ipad version.
        .onAppear() {self.refreshingID = UUID()} //refresh the fetchrequest
    }
    
    func saveEmployeeInfo() {
        employee.name = name
        employee.password = password
        employee.username = username
        employee.type = type.rawValue
        logHandler(employee: employee, in: moc).refreshForChangedType(newType: type)
        trySave(moc: moc)
        saveMessage = "Saved."
    }
}
    
//struct EmployeeAccountView_Previews: PreviewProvider {
//    static var previews: some View {
//        EmployeeAccountView()
//    }
//}
