//
//  EmployeeListView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 29/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct SelectiveList: View {
    @Environment(\.managedObjectContext) var moc
    @Environment(\.editMode) var editMode
    @State private var isPresentingAddView: Binding<Bool>
    var elements: FetchRequest<Employee>
    
    //takes in the filter text and the presenting mode of the add sheet.
    init(filter: String, isPresentingAddView: Binding<Bool>) { //elements will refresh every time list is called, including when employee added
        if filter != "" {
            //assign a fetchRequest with only employees starting with the words.
            elements = FetchRequest<Employee>(entity: Employee.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Employee.name, ascending: true)], predicate: NSPredicate(format: "name BEGINSWITH[c] %@", filter))
        } else {
            //assign a fetchRequest with no predicates. Thinking logically.
            elements = FetchRequest<Employee>(entity: Employee.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Employee.name, ascending: true)]) //all elements
        }
        _isPresentingAddView = State(initialValue: isPresentingAddView)
    }
    
    var body: some View {
        List {
            //Displays the name and username of the filtered or unfiltered fetch request
            ForEach(elements.wrappedValue, id: \.self){ element in
                    NavigationLink(destination: EmployeeAccountView(employee: element, isClient: true)){
                        VStack(alignment: .leading) {
                            Text(element.wrappedName)
                                .font(.headline)
                            Text("\(element.wrappedUserName)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                }
            }
            .onDelete(perform: deleteEmployee)
            .deleteDisabled(!(editMode?.wrappedValue.isEditing ?? false)) //only deletable when editing. Thinking ahead.
        }
    .navigationBarBackButtonHidden(true)
    .navigationBarItems(leading:
        Button(action: {self.isPresentingAddView.wrappedValue.toggle()}){Image(systemName: "plus")}, trailing: EditButton())
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func deleteEmployee(at offsets: IndexSet) {
        for offset in offsets {
            // find this employee in our fetch request
            let employee = elements.wrappedValue[offset]
            // delete it from the context
            moc.delete(employee)
        }
        // save the context
        trySave(moc: moc)
    }
    

}

struct EmployeeListView: View {
    @Environment(\.managedObjectContext) var moc
    var client: Client
    @State var filter = ""
    @State var isPresentingAddView = false

    
    var body: some View {
        NavigationView {
            VStack {
                customSearchBar(searched: $filter) //search bar with filter as the text
                //List that takes in the search filter
                SelectiveList(filter: filter, isPresentingAddView: $isPresentingAddView)
            }
            .sheet(isPresented: $isPresentingAddView){
                AddEmployeeView(client: self.client)
                    .environment(\.managedObjectContext, self.moc)
                .navigationViewStyle(StackNavigationViewStyle())
            }
            .navigationBarTitle("List")
            .navigationBarBackButtonHidden(false)
        .navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct customSearchBar: View {
    var searched: Binding<String>
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass.circle")
                .padding()
            TextField("Search Employee Name Here", text: searched)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
}

//struct EmployeeListView_Previews: PreviewProvider {
//    static var previews: some View {
//        EmployeeListView()
//    }
//}
