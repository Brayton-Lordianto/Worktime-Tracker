//
//  ClientAccountView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 30/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI


struct ClientAccountView: View {
    var client: Client //client
    @Environment(\.managedObjectContext) var moc //managed object context
    @FetchRequest(entity: Month.entity(), sortDescriptors: []) var months: FetchedResults<Month> //all months
    @State private var name: String //basic client information
    @State private var email: String
    @State private var username: String
    @State private var password: String
    @State private var isSaved = false
    @State private var dateToSendAsJson = Date() //the date that is selected by the client to send as JSON.
    private var monthAsText: String {
        "\(DateFormatter().monthSymbols[(components.month ?? 1)-1]) \(components.year ?? 2021)"
    } //UI text
    private var components: DateComponents {
        Calendar.current.dateComponents([.month, .year], from: dateToSendAsJson) //month and year components of the date
    }
    init(client: Client) {
        self.client = client
        _name = State(initialValue: client.wrappedName)
        _email = State(initialValue: client.wrappedEmail)
        _username = State(initialValue: client.wrappedUsername)
        _password = State(initialValue: client.wrappedPassword)
    }
    @State var alertShowing = false

    var body: some View {
        NavigationView {
            Form {
                //editable fields, formatted.
                editableField(text: "Client Name", textFieldContent: $name, disabled: false)
                editableField(text: "Client Email", textFieldContent: $email, disabled: false)
                editableField(text: "Client Username", textFieldContent:$username,disabled: true)
                editableField(text: "Client Password", textFieldContent: $password, disabled: false)
                
                if isSaved {Section {Text("Saved.")}} //saved message
                
                Section(header: Text("Choose A Date To Send As JSON")){ //The datepicker to select the date
                    DatePicker(selection: $dateToSendAsJson, displayedComponents: .date) {Text("")}.labelsHidden()
                    Button("Send Records Of \(monthAsText)"){ //A button to bring up the email sheet
                        let handler = jsonHandler(months: self.months, monthToSend: self.components.month ?? 0, yearToSend: self.components.year ?? 0, client: self.client)
                        handler.emailJsonData(showAlert: self.$alertShowing) //brings up the email sheet.
                    }
                }
            }
            .alert(isPresented: $alertShowing) { //alert appears if there are no records for the selected date. Thinking Ahead
                Alert(title: Text("There are no employees present this whole month. There is no information to be sent."))
            }
            .navigationBarItems(trailing: Button("Save Changes"){
                self.client.name = self.name
                self.client.email = self.email
                self.client.username = self.username
                self.client.password = self.password
                self.isSaved = true
                trySave(moc: self.moc)
            })
            .navigationBarTitle("Profile")
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

//struct ClientAccountView_Previews: PreviewProvider {
//    static var previews: some View {
//        ClientAccountView()
//    }
//}

//                Section {
//                    Button(action: {
//                        self.presentation.wrappedValue.dismiss()
//                        }){
//                        Text("LOG OUT")
//                            .foregroundColor(Color.red)
//                            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
//                    }
//                }
