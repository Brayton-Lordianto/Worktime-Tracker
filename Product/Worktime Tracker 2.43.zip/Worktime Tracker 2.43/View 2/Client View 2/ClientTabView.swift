//
//  ClientTabView.swift
//  Worktime 2.3
//
//  Created by Brayton Lordianto on 30/10/20.
//  Copyright © 2020 Brayton Lordianto. All rights reserved.
//

import SwiftUI

struct ClientTabView: View {
    var client: Client
    @Environment(\.presentationMode) var presentation
    
    var body: some View {
        VStack {
        TabView {
            EmployeeListView(client: client)
                .tabItem{
                    Image(systemName: "list.dash")
                    Text("List")
            }

            ClientAccountView(client: client)
                .tabItem{
                    Image(systemName: "person.circle.fill")
                    Text("Profile")
            }
        }
            Button(action : {self.presentation.wrappedValue.dismiss()}) {Text("LOG OUT").foregroundColor(Color.red)}
        }
        .navigationBarBackButtonHidden(true)
    .navigationViewStyle(StackNavigationViewStyle())
    }
}

//struct ClientTabView_Previews: PreviewProvider {
//    static var previews: some View {
//        ClientTabView()
//    }
//}
