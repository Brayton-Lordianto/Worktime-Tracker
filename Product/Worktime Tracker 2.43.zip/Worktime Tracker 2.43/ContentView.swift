//
//  ContentView.swift
//  Worktime Tracker 2.4
//
//  Created by Brayton Lordianto on 02/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//

import SwiftUI

import SwiftUI
import CoreData

struct testerOnly: Encodable {
    var name: String
    var password: String
    var number = 1
    init(client: Client) {
        name = client.wrappedName
        password = client.wrappedPassword
    }
}

struct ContentView: View {
    @FetchRequest(entity: Client.entity(), sortDescriptors: []) var ClientAccount: FetchedResults<Client>
    @FetchRequest(entity: Employee.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Employee.name, ascending: true)]) var EmployeeAccounts: FetchedResults<Employee>
    @Environment(\.managedObjectContext) var moc
    var handler: credentialsHandler {
        credentialsHandler(username: inputtedUsername, password: inputtedPassword, clientAcc: ClientAccount, employees: EmployeeAccounts, moc: moc)
    }
    var modeText: String {
        isAccountLoginMode ? "Login to Account" : "Check-In | Check-Out"
    }
    @State private var inputtedUsername = ""
    @State private var inputtedPassword = ""
    @State private var errorMessage = ""
    @State private var goClientAccount = false
    @State private var goEmployeeAccount = false
    @State private var EmployeeAcc: Employee? = nil
    @State private var showingAlert: Bool = false
    private var color: Color {
        isAccountLoginMode ? Color.green : Color.yellow
    }
    @State private var isAccountLoginMode: Bool = true
    var loginText: String {
        isAccountLoginMode ? "Login" : "Login to Check-in/Check-out"
    }
    @State var errorOrSuccessColor: Color = Color.red
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [color, Color.blue]), startPoint: .topLeading, endPoint: .bottomTrailing).edgesIgnoringSafeArea(.all)
                VStack {
                    Group {
                        Spacer()
                        HStack {
                            Text("Username: ").font(.title)
                            TextField("Enter Your Username Here", text: $inputtedUsername)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }.padding()
                        HStack {
                            Text("Password: ").font(.title)
                            SecureField("Enter Your Password Here", text: $inputtedPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }.padding()
                        //MARK: Testing Purposes
                        Button(action: {
                                addEmployeesForTesting(in: self.moc)
                                addOtherTypesEmployees(in: self.moc)
                                trySave(moc: self.moc)
                        }){Text("Populate Employees and Logs")}
                        Text(errorMessage).foregroundColor(errorOrSuccessColor).bold().padding()
                        Spacer()
                    }
                    
                    Group {
                        BorderedButton(button: Button("Change The Login Mode"){self.changeModePressed()})
                            BorderedButton(button: Button(loginText){self.login()})
                            BorderedButton(button: Button("Information"){self.showingAlert.toggle()})
                        //MARK: Testing Purposes 2
                            BorderedButton(button: Button("Delete (Testing Purposes)"){
                                for emp in self.EmployeeAccounts {
                                    self.moc.delete(emp)
                                }
                                trySave(moc: self.moc)
                            })
                        
                        Spacer()
                    }
                    
                    Group {
                        if !ClientAccount.isEmpty {
                            NavigationLink(
                                destination: ClientTabView(client: handler.existingUsernameClient() ?? ClientAccount[0]),
                                isActive: $goClientAccount) {
                                    EmptyView()
                            }
                        }
                        if EmployeeAcc != nil {
                            NavigationLink(
                                destination: EmployeeAccountView(employee: EmployeeAcc!, isClient: false),
                                isActive: $goEmployeeAccount
                            ) {
                                EmptyView()
                            }
                        }
                    }
                
                }
            .navigationBarTitle("\(modeText)")
            }
        }
        .onAppear() { //ensures that there will always be a client.
            if self.ClientAccount.count == 0 {
                self.handler.initClient()
            }
        }
        .alert(isPresented: $showingAlert){
            Alert(title: Text(information))
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    //called when the user attempts to change the login Mode
    //account login mode is the default (isAccountLoginMode = true)
    //the login modes: login to the account OR check-in/check-out
    func changeModePressed() {
        errorMessage = handler.handleChangeMode() //check if the credentials are a client's
        if errorMessage == "" {
            //If there is no error in checking client credentials, change the mode (to check in/check out)
            isAccountLoginMode.toggle()
            clearErrors() //clear error messages
        }
        checkForNoFields()
        clearFields() //clear username and password
    }
    
    func checkForNoFields() {
        if inputtedUsername == "" {
            errorMessage = "Please enter a username"
        } else if inputtedPassword == "" {
            errorMessage = "Please enter a password"
        }
    }
    
    func clearFields() {
        inputtedPassword = ""
        inputtedUsername = ""
    }
    
    func clearErrors() {
        errorMessage = ""
    }
            
    func login() {
        errorOrSuccessColor = Color.red
        if (isAccountLoginMode) {
          errorMessage = handler.handleAccountLogin(goClientAccount: $goClientAccount, goEmployeeAccount: $goEmployeeAccount, boundEmployee: $EmployeeAcc)
        } else {
            errorMessage = handler.handleCheckInOutLogin()
        }
        if errorMessage == "" {
            clearErrors()
        }
        clearFields()
    }
    
    
}

struct BorderedButton: View {
    var button: Button<Text>
    var body: some View {
        button
        .frame(minWidth: 0, maxWidth: .infinity)
        .padding()
        .foregroundColor(.white)
        .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .leading, endPoint: .trailing))
        .cornerRadius(40)
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
    }
}

struct longBorderedButton: View {
    var button: Button<Text>
    var body: some View {
        button
        .padding(10)
        .frame(width: 310, height: nil, alignment: .center)
        .overlay(Rectangle().stroke())
    }
}


//testing purposes to populate logs
func fullPopulationForTesting(in moc: NSManagedObjectContext, for employees: FetchedResults<Employee>) {
    print("\(employees.count)")
    populateLogsForTesting(dateSet: wkday10hr, for: employees[0], in: moc)
    populateLogsForTesting(dateSet: wkday7hr, for: employees[1], in: moc)
    populateLogsForTesting(dateSet: wkday2hr, for: employees[2], in: moc)
    populateLogsForTesting(dateSet: wkend10hr, for: employees[3], in: moc)
    populateLogsForTesting(dateSet: wkend7hr, for: employees[4], in: moc)
    populateLogsForTesting(dateSet: wkend2hr, for: employees[5], in: moc)
    populateLogsForTesting(dateSet: fourLogs, for: employees[6], in: moc)
    populateLogsForTesting(dateSet: threeLogs, for: employees[7], in: moc)
    populateLogsForTesting(dateSet: fullMonth, for: employees[8], in: moc)
    populateLogsForTesting(dateSet: threeAbscenes, for: employees[9], in: moc)
    populateLogsForTesting(dateSet: negativeMonthly, for: employees[10], in: moc)
}
func addEmployeesForTesting(in moc: NSManagedObjectContext) {
    let employeeNames = ["Amin A", "Bill Bones", "Cass C", "Delta D", "Emenike E", "Foris F", "Gerald G", "Hubmin H", "Ipin I", "Jack J", "Kite K"]
    let employeeUsernames = ["Amin", "Bill", "Cass", "Delta", "Emenike", "Foris", "Gerald", "Hubmin", "Ipin", "Jack", "Kite"]
    let logSet = [wkday10hr, wkday7hr, wkday2hr, wkend10hr, wkend7hr, wkend2hr, fourLogs, threeLogs, fullMonth, threeAbscenes, negativeMonthly]
    for idx in 0..<employeeNames.count {
        let employee = Employee(context: moc)
        employee.name = employeeNames[idx]
        employee.type = "Normal Pay Employee"
        employee.username = employeeUsernames[idx]
        employee.password = "example"
        populateLogsForTesting(dateSet: logSet[idx], for: employee, in: moc)
    }
    trySave(moc: moc)
}
func addOtherTypesEmployees(in moc: NSManagedObjectContext) {
    let employeeNames = ["Lina L", "Nomad N", "Mark M", "Opal O", "Pike P", "Quentin Q", "Rick R", "Sanders S"]
    let employeeUsernames = ["Lina", "Nomad", "Mark", "Opal", "Pike", "Quentin", "Rick", "Sanders"]
    let logSet = [diligenceOneAbsent, diligenceTwoAbsent, diligentThreeAbsent, diligentFourAbsent, fullMonth, fullMonth, fullMonth, fullMonth]
    for idx in 0..<employeeNames.count {
        let employee = Employee(context: moc)
        if idx < 4 {
            employee.type = "Diligence Pay Employee"
        }
        else if idx == 4{
            employee.type = "Diligence Pay Employee"
        } else if idx == 5 {
            employee.type = "Fixed Extra Pay Employee"
        } else if idx == 6 {
            employee.type = "Canceled Bonus Employee"
        } else if idx == 7 {
            employee.type = "No Extra Pay Employee"
        }
        employee.name = employeeNames[idx]
        employee.username = employeeUsernames[idx]
        employee.password = "example"
        populateLogsForTesting(dateSet: logSet[idx], for: employee, in: moc)
    }
    trySave(moc: moc)
}
func populateLogsForOtherTypes(in moc: NSManagedObjectContext, for employees: FetchedResults<Employee>) {
    populateLogsForTesting(dateSet: diligenceOneAbsent, for: employees[11], in: moc)
    populateLogsForTesting(dateSet: diligenceTwoAbsent, for: employees[12], in: moc)
    populateLogsForTesting(dateSet: diligentThreeAbsent, for: employees[13], in: moc)
    populateLogsForTesting(dateSet: diligentFourAbsent, for: employees[14], in: moc)
    populateLogsForTesting(dateSet: fullMonth, for: employees[15], in: moc)
    populateLogsForTesting(dateSet: fullMonth, for: employees[16], in: moc)
    populateLogsForTesting(dateSet: fullMonth, for: employees[17], in: moc)
    populateLogsForTesting(dateSet: fullMonth, for: employees[18], in: moc)
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
