//
//  Month+CoreDataProperties.swift
//  Worktime Tracker 2.43
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//
//

import Foundation
import CoreData


extension Month {
    @NSManaged public var days: NSSet? //Day entities of the Month entity
    //sort days by date, starting with the earliest.
    public var dayArray: [Day] {
        //return an array from the NSSet, sorted.
        let set = days as? Set<Day> ?? []
        if set != [] {
            return set.sorted {$0.wrappedDate.day! < $1.wrappedDate.day!}  //first element to last is from earliest to latest date.
        }
        else {return []}
    }


    @NSManaged public var diligenceAbsence: Int16
    @NSManaged public var monthDate: Date?
    @NSManaged public var monthOvertime: Int16
    @NSManaged public var employee: Employee?

    public var wrappedDate: DateComponents {
        Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: monthDate ?? Date())
    }
    
    
    public func isEmpty() -> Bool{
        return (dayArray == [])
    }

}

// MARK: Generated accessors for days
extension Month {

    @objc(addDaysObject:)
    @NSManaged public func addToDays(_ value: Day)

    @objc(removeDaysObject:)
    @NSManaged public func removeFromDays(_ value: Day)

    @objc(addDays:)
    @NSManaged public func addToDays(_ values: NSSet)

    @objc(removeDays:)
    @NSManaged public func removeFromDays(_ values: NSSet)

}
