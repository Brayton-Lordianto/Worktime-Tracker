//
//  Log+CoreDataProperties.swift
//  Worktime Tracker 2.43
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//
//

import Foundation


extension Log {
    @NSManaged public var date: Date?
    @NSManaged public var day: Day?
    @NSManaged public var employee: Employee?

    public var wrappedDate: DateComponents {
        Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: date ?? Date())
    }
    
    public var wrappedTime: DateComponents {
        Calendar.current.dateComponents([.hour, .minute, .second], from: date ?? Date())
    }

}
