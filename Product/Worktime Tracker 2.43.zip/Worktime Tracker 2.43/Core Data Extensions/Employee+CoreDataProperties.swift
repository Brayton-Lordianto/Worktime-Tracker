//
//  Employee+CoreDataProperties.swift
//  Worktime Tracker 2.43
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//
//

import Foundation
import CoreData


extension Employee {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employee> {
        return NSFetchRequest<Employee>(entityName: "Employee")
    }

    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var password: String?
    @NSManaged public var type: String?
    @NSManaged public var username: String?
    @NSManaged public var days: NSSet?
    @NSManaged public var logs: NSSet?
    @NSManaged public var months: NSSet?

    public var wrappedUserName: String {
        username ?? "Unknown Username"
    }
    
    public var wrappedName: String {
        name ?? "Unknown Name"
    }
    
    public var wrappedPassword: String {
        password ?? "Unknown Password"
    }
    
    public var wrappedType: types {
        for type in types.allCases {
            if  self.type == type.rawValue {
                return type
            }
        }
        return types.normalPay
    }
    
    public var monthsArray: [Month] {
        let set = self.months as? Set<Month> ?? []
        return set.sorted {
            String(describing: $0.wrappedDate) < String(describing: $1.wrappedDate)
        }
    }
    
    public var daysArray: [Day] {
        let set = days as? Set<Day> ?? []
        return set.sorted {
            String(describing: $0.wrappedDate) < String(describing: $1.wrappedDate)
        }
    }

}

// MARK: Generated accessors for days
extension Employee {

    @objc(addDaysObject:)
    @NSManaged public func addToDays(_ value: Day)

    @objc(removeDaysObject:)
    @NSManaged public func removeFromDays(_ value: Day)

    @objc(addDays:)
    @NSManaged public func addToDays(_ values: NSSet)

    @objc(removeDays:)
    @NSManaged public func removeFromDays(_ values: NSSet)

}

// MARK: Generated accessors for logs
extension Employee {

    @objc(addLogsObject:)
    @NSManaged public func addToLogs(_ value: Log)

    @objc(removeLogsObject:)
    @NSManaged public func removeFromLogs(_ value: Log)

    @objc(addLogs:)
    @NSManaged public func addToLogs(_ values: NSSet)

    @objc(removeLogs:)
    @NSManaged public func removeFromLogs(_ values: NSSet)

}

// MARK: Generated accessors for months
extension Employee {

    @objc(addMonthsObject:)
    @NSManaged public func addToMonths(_ value: Month)

    @objc(removeMonthsObject:)
    @NSManaged public func removeFromMonths(_ value: Month)

    @objc(addMonths:)
    @NSManaged public func addToMonths(_ values: NSSet)

    @objc(removeMonths:)
    @NSManaged public func removeFromMonths(_ values: NSSet)

}
