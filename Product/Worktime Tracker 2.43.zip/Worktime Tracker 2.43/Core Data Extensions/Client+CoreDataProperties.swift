//
//  Client+CoreDataProperties.swift
//  Worktime Tracker 2.43
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//
//

import Foundation
import CoreData


extension Client {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Client> {
        return NSFetchRequest<Client>(entityName: "Client")
    }

    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var password: String?
    @NSManaged public var username: String?

    public var wrappedUsername: String {
        username ?? "Unknown Username"
    }
    
    public var wrappedEmail: String {
        email ?? "Unknown Email"
    }
    
    public var wrappedName: String {
        name ?? "Unknown Name"
    }
    
    public var wrappedPassword: String {
        password ?? "Unknown Password"
    }

}
