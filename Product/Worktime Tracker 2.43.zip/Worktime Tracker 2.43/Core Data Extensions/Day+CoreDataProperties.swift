//
//  Day+CoreDataProperties.swift
//  Worktime Tracker 2.43
//
//  Created by Brayton Lordianto on 06/02/21.
//  Copyright © 2021 Brayton Lordianto. All rights reserved.
//
//

import Foundation
import CoreData


extension Day {

    @NSManaged public var dayDate: Date?
    @NSManaged public var dayOvertime: Int16
    @NSManaged public var worktime: Int16
    @NSManaged public var employee: Employee?
    @NSManaged public var logs: NSSet? //inverse relationship to Log
    @NSManaged public var month: Month?

    //the logs NSSet is returned as a more Swift-friendly type– an array of Log entities.
    //the array is sorted by date.
    public var logArray: [Log] {
        let set = logs as? Set<Log> ?? [] //cast as a set
        if set != [] {
            return set.sorted {
                //The array is sorted from the earliest date (time) to the latest date (time).
                String(describing: $0.date!) < String(describing: $1.date!)
            }
        }
        return []
    }
    
    public var wrappedDate: DateComponents {
        Calendar.current.dateComponents(in: TimeZone(abbreviation: "UTC")!, from: dayDate ?? Date())
    }
    
    func isEmpty() -> Bool { //everytime a log is deleted, call this method.
        return (logArray == [])
    }

}

// MARK: Generated accessors for logs
extension Day {

    @objc(addLogsObject:)
    @NSManaged public func addToLogs(_ value: Log)

    @objc(removeLogsObject:)
    @NSManaged public func removeFromLogs(_ value: Log)

    @objc(addLogs:)
    @NSManaged public func addToLogs(_ values: NSSet)

    @objc(removeLogs:)
    @NSManaged public func removeFromLogs(_ values: NSSet)

}
